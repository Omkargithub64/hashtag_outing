#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct Student{
    char name[20];
    char usn[20];
    int password;
    int phone;
    int room;
};
struct Student student[10];

struct Outing{
    char name[20];
    int phone;
    int room;
    char type[20];
    char date[20];
    int allowed;
};

struct Outing outing[10];

struct Warden{
    char name[20];
    int password;
};

struct Warden warden;




void set_outing_request(int student_id, char type[], char date[], int allowed){
    FILE *file, *temp;
    
    char buffer[100];
    char replace[100];
    int replace_line = student_id;
    int keep_reading = 1;
    int current = 1;
    // strcpy(replace,"")

    file = fopen("database/outing.txt","r");
    temp = fopen("database/temp_outing.txt","w");
do
    {
        fgets(buffer,100,file);
        if (feof(file))
        {
            keep_reading = 0;
        }
        else if(replace_line == current){
            fprintf(temp,"%s %d %d %s %s %d\n",student[student_id-1].name,student[student_id-1].phone,student[student_id-1].room,type,date,allowed);
            // sscanf(buffer,"%s %s %d %d %d",student[*read_line-1].name,student[*read_line-1].usn,&student[*read_line-1].password,&student[*read_line-1].phone,&student[*read_line-1].room);
            // printf("%s", line);
        }
        else{
            fputs(buffer,temp);
        }
        current++;
        
        
    } while (keep_reading);
    fclose(file);
    fclose(temp);

    remove("database/outing.txt");
    rename("database/temp_outing.txt","database/outing.txt");



}

void get_outing_data(int read_line){
    FILE *outing_file;
    char buffer[100];
    int keep_reading=1,current = 1;
    outing_file = fopen("database/outing.txt","r");

    do
    {
        fgets(buffer,100,outing_file);
        if (feof(outing_file))
        {
            keep_reading = 0;
        }
        else if(read_line == current){
            keep_reading = 0;
            sscanf(buffer,"%s %d %d %s %s %d",outing[read_line-1].name,&outing[read_line-1].phone,&outing[read_line-1].room,outing[read_line-1].type,outing[read_line-1].date,&outing[read_line-1].allowed);
        }
        current++;
        
        
    } while (keep_reading);
    

    fclose(outing_file);
}



void get_student(int read_line){
    FILE *student_file;
    char buffer[100];
    int keep_reading=1,current = 1;
    student_file = fopen("database/students.txt","r");

    do
    {
        fgets(buffer,100,student_file);
        if (feof(student_file))
        {
            keep_reading = 0;
        }
        else if(read_line == current){
            keep_reading = 0;
            sscanf(buffer,"%s %s %d %d %d",student[read_line-1].name,student[read_line-1].usn,&student[read_line-1].password,&student[read_line-1].phone,&student[read_line-1].room);
            // printf("%s", line);
        }
        current++;
        
        
    } while (keep_reading);
    

    fclose(student_file);

}

void get_warden(){
    FILE *warden_file;
    char buffer[100];
    warden_file = fopen("database/warden.txt","r");

    fscanf(warden_file,"%s %d",warden.name,&warden.password);

    fclose(warden_file);
    printf("\n%s \n\n",buffer);


}

void main_screen(int student_id){
    int ch,outing_ch,logedin = 1;
    int selected_std[10],num;
    char date[10],type[10];
    int allowed = 0;
    int allo;
    int notification=0;
    printf("\n\n ====== Welcom %s ======\n\n",warden.name);
    while(logedin){
        for (int i = 1; i < 15; i++)
        {
        get_outing_data(i);
        get_student(i);
        }

        int count = 0;
            printf("===================================================================================\n");
        printf("\nId\t | Name \t | Phone \t | Room \t | Type \t | Date\n\n");
        // printf("---------------------------------------------------------------------------------\n");
        printf("===================================================================================\n");
        for (int i = 1; i < 15; i++)
        {
            if(outing[i-1].phone == 0){
                continue;
            }
            if(outing[i-1].allowed >= 1 ){
                continue;
            }
        count++;

        if (count != 0)
        {
            printf("\n%d \t | %s \t | %d \t | %d \t\t | %s \t | %s \n\n",i,outing[i-1].name,outing[i-1].phone,outing[i-1].room,outing[i-1].type,outing[i-1].date);
            printf("-----------------------------------------------------------------------------------\n");
            /* code */
        }
        
        }
        
        printf("===================================================================================\n");
        if (count != 0)
        {
            /* code */
        
        printf("=== 1. Select Students       \n");
        // printf("=== 2. select all            ===\n");
        printf("=== 2. Log out               \n");
        }
        else{
        printf("=== No Outing Request        \n");
        printf("=== 2. Log out               \n");

        }
        printf("===================================================================================\n\n\n\n");

        printf("=> your choice: ");
        scanf("%d",&ch);
        

        switch (ch)
        {
        case 1:
        if (count != 0)
        {
            /* code */
        
            printf("Select students:\n");
            printf("Enter number of students: ");
            scanf("%d",&num);
            printf("Enter students id: ");

            for(int i = 0;i<num;i++){
                scanf("%d",&selected_std[i]);
            }
            printf("\n");
            printf("===================================================================================\n");
            printf("\nId\t | Name \t | Phone \t | Room \t | Type \t | Date\n\n");
            printf("===================================================================================\n");
            for (int i = 0; i < num; i++)
            {
                
            printf("\n%d \t | %s \t | %d \t | %d \t\t | %s \t | %s \n\n",selected_std[i],outing[selected_std[i]-1].name,outing[selected_std[i]-1].phone,outing[selected_std[i]-1].room,outing[selected_std[i]-1].type,outing[selected_std[i]-1].date);
            printf("-----------------------------------------------------------------------------------\n");
            
            }
            printf("\n");
            printf("===================================================================================\n");
            printf("=== 1. Allow                 \n");
            printf("=== 2. Deny                  \n");
            printf("=== 3. Back                  \n");
            printf("===================================================================================\n\n\n\n");

            printf("=> your choice: ");
            scanf("%d",&allo);
            

            switch (allo)
            {
            case 1:
            for (int i = 0; i < num; i++)
            {
            // printf("%s \t\t\t%d \t\t\t%d \t\t\t%s \t\t\t%s \n",outing[selected_std[i]-1].name,outing[selected_std[i]-1].phone,outing[selected_std[i]-1].room,outing[selected_std[i]-1].type,outing[selected_std[i]-1].date);
                set_outing_request(selected_std[i],outing[selected_std[i]-1].type,outing[selected_std[i]-1].date,1);
            }
                break;
            case 2:
            for (int i = 0; i < num; i++)
            {
            // printf("%s \t\t\t%d \t\t\t%d \t\t\t%s \t\t\t%s \n",outing[selected_std[i]-1].name,outing[selected_std[i]-1].phone,outing[selected_std[i]-1].room,outing[selected_std[i]-1].type,outing[selected_std[i]-1].date);
                set_outing_request(selected_std[i],outing[selected_std[i]-1].type,outing[selected_std[i]-1].date,2);
            }
                break;
            case 3:
                
                break;

            default:
            printf("Invalid choice\n");
                break;
            }
        }
            break;
        case 2:
            logedin = 0;
            break;
        
        default:
        printf("Invalid choice\n");
            break;
        }

    }


}



int main(){

    // LOGIN
    int ch,entered_id,entered_password;
    printf("===== Warden LOGIN ====\n");
    // printf("%d",student[student_id-1].password);
    while(1){
        printf("================================\n");
        printf("=== 1. Login\n");
        printf("=== 2. Exit\n");
        printf("================================\n");
        printf("================================\n");
        printf("please enter your choice: \n");
        scanf("%d",&ch);
        printf("================================\n");
        switch(ch){
            case 1:
            printf("================================\n");
            printf("===  Enter Your id:");
            scanf("%d",&entered_id);
            printf("===  Enter Your Password:");
            scanf("%d",&entered_password);
            printf("================================\n");
            get_warden();
            if(warden.password == entered_password){
                printf("\nyou are Logged in.\n\n ");
                main_screen(entered_id);
            }else{
                printf("\n!!!!!!!! You entered wrong password or id !!!!!!!! \n\n");
                printf("\n%d \n\n",warden.password);

            }
            break;

            case 2:
            exit(0);
            break;

            default:
            printf("!!!!!!!! Enter correct choice !!!!!!!! \n\n");

        }





    }




    return 0;
}

