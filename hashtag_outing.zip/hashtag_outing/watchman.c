#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct Student{
    char name[20];
    char usn[20];
    int password;
    int phone;
    int room;
};
struct Student student;

struct Outing{
    char name[20];
    int phone;
    int room;
    char type[20];
    char date[20];
    int allowed;
};

struct Outing outing[100];

struct Warden{
    char name[20];
    int password;
};

struct Warden warden;



void get_outing_data(){
    FILE *outing_file;
    int read_line = 1;
    char buffer[100];
    int keep_reading=1,current = 1;
    outing_file = fopen("database/outing.txt","r");

    printf("===================================================================================\n");
    printf("\nId\t | Name \t | Phone \t | Room \t | Type \t | Date\n\n");
    // printf("---------------------------------------------------------------------------------\n");
    printf("===================================================================================\n");
        

    do
    {
        fgets(buffer,100,outing_file);
        if (feof(outing_file))
        {
            keep_reading = 0;
        }
        else{
            
            sscanf(buffer,"%s %d %d %s %s %d",outing[read_line].name,&outing[read_line].phone,&outing[read_line].room,outing[read_line].type,outing[read_line].date,&outing[read_line].allowed);

            if (outing[read_line].phone == 0)
            {
                read_line++;
                continue;
            }
            else if(outing[read_line].allowed == 2){
                read_line++;
                continue;
            }
            
            
            printf("\n%d \t | %s \t | %d \t | %d \t\t | %s \t | %s \n\n",read_line,outing[read_line].name,outing[read_line].phone,outing[read_line].room,outing[read_line].type,outing[read_line].date);
            printf("-----------------------------------------------------------------------------------\n");
            
        }
            read_line++;
    } while (keep_reading);
    

    fclose(outing_file);

}


int get_student_outing_data(int read_line){
    FILE *outing_file;
    char buffer[100];
    int keep_reading=1,current = 1;
    outing_file = fopen("database/outing.txt","r");

    do
    {
        fgets(buffer,100,outing_file);
        if (feof(outing_file))
        {
            keep_reading = 0;
        }
        else if(read_line == current){
            keep_reading = 0;
            sscanf(buffer,"%s %d %d %s %s %d",outing[read_line-1].name,&outing[read_line-1].phone,&outing[read_line-1].room,outing[read_line-1].type,outing[read_line-1].date,&outing[read_line-1].allowed);
            // printf("%s", line);
        }
        current++;
        
        
    } while (keep_reading);
    

    fclose(outing_file);
    return 0;
}



void get_student(int read_line){
    FILE *student_file;
    char buffer[100];
    int keep_reading=1,current = 1;
    student_file = fopen("database/students.txt","r");

    do
    {
        fgets(buffer,100,student_file);
        if (feof(student_file))
        {
            keep_reading = 0;
        }
        else if(read_line == current){
            keep_reading = 0;
            sscanf(buffer,"%s %s %d %d %d",student.name,student.usn,&student.password,&student.phone,&student.room);
            // printf("%s",student.usn);
        }
        current++;
        
        
    } while (keep_reading);
    

    fclose(student_file);

}


void delete_outing_request(int student_id){
    FILE *file, *temp;
    
    char buffer[100];
    char replace[100];
    int replace_line = student_id;
    int keep_reading = 1;
    int current = 1;
    // strcpy(replace,"")

    file = fopen("database/outing.txt","r");
    temp = fopen("database/temp_outing.txt","w");
do
    {
        fgets(buffer,100,file);
        if (feof(file))
        {
            keep_reading = 0;
        }
        else if(replace_line == current){
            fprintf(temp,"\n");
            // sscanf(buffer,"%s %s %d %d %d",student[*read_line-1].name,student[*read_line-1].usn,&student[*read_line-1].password,&student[*read_line-1].phone,&student[*read_line-1].room);
            // printf("%s", line);
        }
        else{
            fputs(buffer,temp);
        }
        current++;
        
        
    } while (keep_reading);
    fclose(file);
    fclose(temp);

    remove("database/outing.txt");
    rename("database/temp_outing.txt","database/outing.txt");



}






int main(){

    // main_screen();
    int ch,id;
    char eusn[10];
    
    get_outing_data();

    while (1)
    {
        /* code */
    
    printf("================================\n");
    printf("=== 1. Search Id             ===\n");
    printf("=== 2. exit                  ===\n");
    printf("================================\n\n\n\n");

    printf("=> your choice: ");
    scanf("%d",&ch);
    printf("================================\n");
    switch (ch)
    {
    case 1:

        printf("=> Enter id: ");
        scanf("%d",&id);
        get_student_outing_data(id);
        get_student(id);
        

        if(outing[id].phone != 0 && outing[id].allowed == 1){
            // printf("usn: %s\n",student.usn);
            // get_outing_data();
            printf("\n\nUSN : %s\n",student.usn);
            printf("%s is allowed to go out\n\n",student.name);
            delete_outing_request(id);
        }
        else{
            printf("\n\nUSN : %s\n",student.usn);
            printf("%s is not allowed to go out\n\n",student.name);
        }
        // get_outing_data();

        break;
    case 2:
        exit(0);
    default:
        printf("Invalid Choice\n");
        break;
    }
    
    }




    return 0;
}

