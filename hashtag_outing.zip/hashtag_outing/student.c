#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>


struct Student{
    char name[20];
    char usn[20];
    int password;
    int phone;
    int room;
};
struct Student student[10];

struct Outing{
    char name[20];
    // char usn[20];
    int phone;
    int room;
    char type[20];
    char date[20];
    int allowed;
};

struct Outing outing[10];




void set_outing_request(int student_id, char type[], char date[], int allowed){
    FILE *file, *temp;
    
    char buffer[100];
    char replace[100];
    int replace_line = student_id;
    int keep_reading = 1;
    int current = 1;
    // strcpy(replace,"")

    file = fopen("database/outing.txt","r");
    temp = fopen("database/temp_outing.txt","w");
do
    {
        fgets(buffer,100,file);
        if (feof(file))
        {
            keep_reading = 0;
        }
        else if(replace_line == current){
            fprintf(temp,"%s %d %d %s %s %d\n",student[student_id-1].name,student[student_id-1].phone,student[student_id-1].room,type,date,allowed);
            // sscanf(buffer,"%s %s %d %d %d",student[*read_line-1].name,student[*read_line-1].usn,&student[*read_line-1].password,&student[*read_line-1].phone,&student[*read_line-1].room);
            // printf("%s", line);
        }
        else{
            fputs(buffer,temp);
        }
        current++;
        
        
    } while (keep_reading);
    fclose(file);
    fclose(temp);

    remove("database/outing.txt");
    rename("database/temp_outing.txt","database/outing.txt");



}


void update_student(int student_id, int phone, int room){
    FILE *file, *temp;
    
    char buffer[100];
    char replace[100];
    int replace_line = student_id;
    int keep_reading = 1;
    int current = 1;
    // strcpy(replace,"")

    file = fopen("database/students.txt","r");
    temp = fopen("database/temp_students.txt","w");
do
    {
        fgets(buffer,100,file);
        if (feof(file))
        {
            keep_reading = 0;
        }
        else if(replace_line == current){
            fprintf(temp,"%s %s %d %d %d\n",student[replace_line-1].name,student[replace_line-1].usn,student[replace_line-1].password,phone,room);
            // sscanf(buffer,"%s %s %d %d %d",student[*read_line-1].name,student[*read_line-1].usn,&student[*read_line-1].password,&student[*read_line-1].phone,&student[*read_line-1].room);
            // printf("%s", line);
        }
        else{
            fputs(buffer,temp);
        }
        current++;
        
        
    } while (keep_reading);
    fclose(file);
    fclose(temp);

    remove("database/students.txt");
    rename("database/temp_students.txt","database/students.txt");



}





void get_outing_data(int read_line){
    FILE *outing_file;
    char buffer[100];
    int keep_reading=1,current = 1;
    outing_file = fopen("database/outing.txt","r");

    do
    {
        fgets(buffer,100,outing_file);
        if (feof(outing_file))
        {
            keep_reading = 0;
        }
        else if(read_line == current){
            keep_reading = 0;
            sscanf(buffer,"%s %d %d %s %s %d",outing[read_line-1].name,&outing[read_line-1].phone,&outing[read_line-1].room,outing[read_line-1].type,outing[read_line-1].date,&outing[read_line-1].allowed);
            // printf("%s", line);
        }
        current++;
        
        
    } while (keep_reading);
    

    fclose(outing_file);
}



void get_student(int *read_line){
    FILE *student_file;
    char buffer[100];
    int keep_reading=1,current = 1;
    student_file = fopen("database/students.txt","r");

    do
    {
        fgets(buffer,100,student_file);
        if (feof(student_file))
        {
            keep_reading = 0;
        }
        else if(*read_line == current){
            keep_reading = 0;
            sscanf(buffer,"%s %s %d %d %d",student[*read_line-1].name,student[*read_line-1].usn,&student[*read_line-1].password,&student[*read_line-1].phone,&student[*read_line-1].room);
            // printf("%s", line);
        }
        current++;
        
        
    } while (keep_reading);
    

    fclose(student_file);

}

void main_screen(int student_id){
    int ch,outing_ch,logedin = 1;
    char date[10],type[10],submit;
    int allowed = 0;
    int notification=0;
    int option = 1;
    printf("\n\n ======== Welcom %s ========\n\n",student[student_id-1].name);
    while(logedin){
        get_outing_data(student_id);
        allowed = outing[student_id-1].allowed;
        if (allowed > 0)
        {
            notification = 1;
        }
        printf("================================\n");
        printf("=== 1. Notification (%d)      ===\n",notification);
        printf("=== 2. Refresh               ===\n");
        printf("=== 3. Choose Outing Type v  ===\n");
        printf("=== 4. Settings              ===\n");
        printf("=== 5. Log out               ===\n");
        printf("================================\n\n\n\n");

        printf("=> your choice: ");
        scanf("%d",&ch);
        printf("================================\n");

        switch (ch)
        {
        case 1:
            printf("\n\nNotification:\n");
            get_outing_data(student_id);
            if(outing[student_id-1].allowed == 1){
                printf("--- Warden Has Accepted your  %s Request\n\n",outing[student_id-1].type);
            }
            else if(outing[student_id-1].allowed == 2){
                printf("--- Warden Has Rejected your %s Request\n\n",outing[student_id-1].type);

            }
            else{
                printf("--- Your %s Request is pending \n\n",outing[student_id-1].type);

            }
            break;
        case 2:
            get_outing_data(student_id);
            allowed = outing[student_id-1].allowed;
            if (allowed > 0)
            {
                notification = 1;
            }
            //delete outing permission

            printf("\n\nRefreshed....\n\n");
            
            break;
        case 3:
            
            printf("=======================================\n");
            printf("==v     1. Sick                     ===\n");
            printf("==v     2. Casual                   ===\n");
            printf("==v     3. Academics                ===\n");
            printf("==v     4. Home Going               ===\n");
            printf("==v     5. Others                   ===\n");
            printf("==v     6. Back                     ===\n");
            printf("=======================================\n\n\n\n");
            printf("=> your choice: ");
            scanf("%d",&outing_ch);
            
            switch(outing_ch){
                case 1:
                    strcpy(type,"Sick");
                    option = 1;
                    break;
                case 2:
                    strcpy(type,"Casual");
                    option = 1;
                    break;
                case 3:
                    strcpy(type,"Academics");
                    option = 1;
                    break;
                case 4:
                    strcpy(type,"HomeGoing");
                    option = 1;
                    break;
                case 5:
                    strcpy(type,"Other");
                    option = 1;
                    break;
                case 6:
                    option = 0;
                    break;
                default:
                    printf("You have entered wrong option \n");
                    option = 0;
                    break;
            }
            if(option == 1){
                printf("\n\n===========  %s  =============\n\n",type);
                printf("Details: \n");
                printf("==>  Name: %s\n",student[student_id-1].name);
                printf("==>  Phone: %d\n",student[student_id-1].phone);
                printf("==>  Room No.: %d\n",student[student_id-1].room);
                printf("==>  Enter Date: ");
                scanf("%s",date);
                allowed = 0;
                printf("Submit? (y/n): ");
                fflush(stdin);
                scanf("%c",&submit);
                if (submit == 'y')
                {
                set_outing_request(student_id,type,date,allowed);
                printf("\n\n----> Your Request has been sent\n\n\n");
                    /* code */
                }
                else{
                printf("\n\n----> Your Request is cancalled\n\n\n");

                }
                
            }
            break;
        case 4:
            printf("\n================== Settings ==================\n\n");
            printf("\nAsk your Warden's Permission to update.\n\n");
            // char name[20],usn[10];
            // int phone,room;
            // printf("==>  Enter Name: ");
            // scanf("%s",name);
            // printf("==>  Enter USN: ");
            // scanf("%s",usn);
            // printf("==>  Enter Phone no: ");
            // scanf("%d",&phone);
            // printf("==>  Enter Room no: ");
            // scanf("%d",room);
            // printf("\n\n");
            // update_student(student_id,phone,room);
            break;
        case 5:
            printf("\n---- You are Logged Out. ---- \n");
            logedin = 0;
            break;
        default:
            printf("\n-----You have entered wrong option -----\n\n");
            break;
        }

    }


}



int main(){

    // LOGIN
    int entered_id,entered_password;
    char ch;
    printf("===== #OUTING Student LOGIN ====\n\n");
    // printf("%d",student[student_id-1].password);
    while(1){
        printf("================================\n");
        printf("===                          ===\n");
        printf("=== 1. Login                 ===\n");
        printf("=== 2. Forgot password ?     ===\n");
        printf("=== 3. Exit                  ===\n");
        printf("===                          ===\n");
        printf("================================\n\n");
        
        printf("=> choice: \n");
        scanf("%c",&ch);
        printf("================================\n\n");
        switch(ch){
            case '1':
            
            printf("===  Enter Your id:");
            scanf("%d",&entered_id);
            printf("===  Enter Your Password:");
            scanf("%d",&entered_password);
            printf("================================\n");
            get_student(&entered_id);
            if(student[entered_id-1].password == entered_password){
                printf("\n--------Student Logged in-------\n");
                main_screen(entered_id);
            }else{
            printf("\n------ You entered wrong password or id ------ \n\n");

            }
            break;

            case '2':
            printf("Inform Your Warden to change your password\n\n");
            break;

            case '3':
            exit(0);
            break;

            default:
            printf("\n---------- Enter correct choice ----------- \n\n");

        }





    }




    return 0;
}

